Online Course Registration System

ADMIN-
	Username:admin
	Password:future2040
Student-	
	User number:110
	password: future2040

HOW IT WORKS.

Students are expected to pay 70% of their fees before they can register.
confirmation of students fee payment can be done in two ways;

i)before registrations are open Accounts department can submit list of all students eligible for registration
and then the administrator can send the students their login details through email and they can register.

ii) Students can email administrator their pay in slip and then wait from confirmation from administrator.if
administrator confirms , he will then send their login details to them.

Either of the two ways can work. so you can choose one.

Administrator deletes all registered students from the system after the semester has ended so he can generate new login 
details.

contact me on kuudaarsixtus@gmail.com for more clarification or +18509601838