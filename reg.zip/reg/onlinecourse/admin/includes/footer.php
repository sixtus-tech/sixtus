<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2019 Online Course Registration | By : <a href="http://www.recas-ghana.com/" target="_blank">ReCAS</a>
                </div>

            </div>
        </div>
    </footer>