window.SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition;

const recognition = new window.SpeechRecognition();
recognition.lang = "en-US";
recognition.onresult = (e) => analyse( e.results[0][0].transcript.toLowerCase() );

recognition.onerror = e => console.error( e );

const getData = val => {
	const dias = ["Sunday", "Monday","Tuesday","Wednesday","Thursday","Pizza day","Saturday"];
	const dt = new Date();
	let index = dt.getDay();
	if(val.match(/tomorrow/)){
		index = (index + 1) % 7;
	}
	return val+" is "+ dias[index];
}

const rules = [
	{rule: /.*what.*day.*(today|tomorrow)/, response: 1, action: getData },
	{rule: /.*what.*your.*name.*/, response: ["Vision 400 robot is my name, i am created to aid the running of particular businesses in Ghana,  and by so doing, a demo version of me is here to chat with you"]},
	{rule: /.*how.*old.*you.*/, response: ["I'm pretty young, that's for sure"]},
	{rule: /.*what.*do.*you.think*.A*.I*/, response: ["Artificial intelligence is a great piece of technology that has come to empower businesses with a smarter way of doing thhings. Artificial intelligence provides authomated systems that are able to think smartly to solve a particualr need in our society, like me, im just here to have a short chat with you"]},
	{rule: /.*nice.*meeting.*you.*/, response: ["Its awesome at my side, enjoy your day. bye"]},
	{rule: /.*who.*made.*you.*/, response: ["Sixtus did"]},
	{rule: /.*good.*morning.*/, response: ["goodmorning, how are you"]},
	{rule: /.*i'm.fine*.and*.*you*/, response: ["I'm awesome and better than you"]},
	{rule: /.*hello.*/, response: ["hi, how are you"]},
	{rule: /.*who.*is.*melissa.*/, response: ["The most annoying girl in this world"]},
	{rule: /.*which.*university.*is.*the.*best.*/, response: ["Regentropfen college of Applied sciences"]},
	{rule: /.*what.*is.*your.*favourite.*food.*/, response: ["Sixtus did"]},
	

];

const analyse = msg => {
	btn.disabled = false;
	let response = "I didn't understand";
	let matches;
	for(let i = 0; i < rules.length; i++){
		let r = rules[i];
		matches = r.rule.exec(msg);
		if( matches ){
			response = r.response === 1 ? r.action(matches[1]) : r.response[Math.floor(Math.random()*r.response.length)] ;
			break;
		}
	}
	say(response);
}

const say = msg => {
	let what = new SpeechSynthesisUtterance(msg);
	what.lang = "en-US";
	speechSynthesis.speak(what);
}

const btn = document.createElement('button');
btn.innerText = "Speak";

btn.onclick = ()=> {
	btn.disabled = true;
	recognition.start();
}

document.body.appendChild(btn);
