#include<iostream>
#include<string>
#include<fstream>



using namespace std;

class Login{
	public:
		string username,password;
		Login()
		{
		
		username="\0";
		password="\0";
	};
	bool isLogIn();
};

bool Login :: isLogIn()
{
	string ch_username="sixtus", ch_password="test1", Yes="c++........A\n";
	cout<<"Enter username::\t";
	cin>>username;
	cout<<"Enter password::\t";
	cin>>password;
	
	if (ch_username==username && ch_password==password)
	{
		cout<<"see Results_ Yes/No::/t";
		//cin<<Yes;
	}
	else
		{
			return false;
		}
	}
		
		
		int main() {
			Login l1;
			bool status = l1.isLogIn();
			if(!status)
			{
				cout<<"\n\tlogin failed Register first\n";
				return 1;
			}
			else
			{
				cout<<"\n\t welcome"<<l1.username<<"!\n";
				return 0;
			}
		}

